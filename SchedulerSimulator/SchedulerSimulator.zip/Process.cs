﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulerSimulator
{
    public class Process
    {
        public int Id { get; set; }
        public DateTime ArrivalTime { get; set; }
        public int BurstTime { get; set; }
        public string State { get; set; }

        public Process(int id, DateTime arrivalTime, int burstTime, string state)
        {
            Id = id;
            ArrivalTime = arrivalTime;
            BurstTime = burstTime;
            State = state;
        }
    }
}
